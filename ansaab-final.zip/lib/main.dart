import 'package:flutter/material.dart';
import 'genealogy_canvas_widget.dart';

void main() {
  runApp(const AnsaabApp());
}

class AnsaabApp extends StatelessWidget {
  const AnsaabApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'مرسم الأنساب الرقمي',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Cairo',
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF4C8C4A)),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String _elementsJson = '{"elements":[]}';
  bool _exportTrigger = false;

  void _triggerExport() {
    setState(() => _exportTrigger = true);
    // reset after frame
    Future.delayed(const Duration(milliseconds: 100), () {
      if (mounted) setState(() => _exportTrigger = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('مرسم الأنساب الرقمي'),
        actions: [
          IconButton(
            icon: const Icon(Icons.download),
            tooltip: 'تصدير PDF',
            onPressed: _triggerExport,
          ),
        ],
      ),
      body: GenealogyCanvas(
        elementsJson: _elementsJson,
        onElementsChanged: (updatedJson) async {
          setState(() => _elementsJson = updatedJson);
        },
        triggerExport: _exportTrigger,
        onExportComplete: (filePath) async {
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('تم التصدير: $filePath')),
          );
        },
      ),
    );
  }
}
