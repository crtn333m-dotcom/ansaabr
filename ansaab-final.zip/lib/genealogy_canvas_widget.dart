// ============================================================================
// GenealogyCanvasWidget.dart
// Custom Widget لـ FlutterFlow — مساحة رسم شجرة العائلة (مرسم الأنساب الرقمي)
// ============================================================================
//
// طريقة التركيب في FlutterFlow:
// 1) من تبويب Custom Code -> Custom Widgets -> أنشئ ويدجت جديد باسم
//    GenealogyCanvas، ثم الصق هذا الملف بالكامل في خانة الكود (استبدل المحتوى
//    الافتراضي بالكامل).
// 2) أضف Widget Parameters التالية:
//      - elementsJson    (String)  -> يمرَّر من App State (JSON كامل للعناصر)
//      - triggerExport   (bool)    -> نبضة تشغيل التصدير (false->true)
// 3) أضف Widget Action Parameters التالية:
//      - onElementsChanged (Action, parameter: updatedJson -> String)
//        يُستدعى مرة واحدة فقط بعد كل تغيير دائم (إفراج السحب، إضافة، حذف،
//        تعديل نص، قفل) — هذا هو الجسر الوحيد بين الويدجت و App State.
//      - onExportComplete  (Action, parameter: filePath -> String)
//        يُستدعى مرة واحدة بعد انتهاء التصدير، يحمل مسار ملف PDF النهائي.
// 4) في الصفحة الرئيسية، اسحب GenealogyCanvas كعنصر، واربط:
//      elementsJson      = FFAppState().genealogyElementsJson
//      triggerExport     = pageState.exportRequested  (bool، toggle عبر زر "تصدير")
//      onElementsChanged -> Custom Action: saveGenealogyState(updatedJson)
//      onExportComplete  -> Custom Action: handleExportComplete(filePath)
//
// تبعيات خارجية مطلوبة (Dependencies tab في FlutterFlow):
//   - path_provider
//   - pdf
// (لا توجد أي تبعيات أخرى — باقي الملف يستخدم Flutter SDK فقط)
// ============================================================================

import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui' as ui;
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/widgets.dart' as pw;

// ----------------------------------------------------------------------------
// 1) نموذج البيانات (Data Model)
// ----------------------------------------------------------------------------

enum ElementType { trunk, branch, leaf }

ElementType _typeFromString(String s) {
  switch (s) {
    case 'branch':
      return ElementType.branch;
    case 'leaf':
      return ElementType.leaf;
    default:
      return ElementType.trunk;
  }
}

String _typeToString(ElementType t) {
  switch (t) {
    case ElementType.branch:
      return 'branch';
    case ElementType.leaf:
      return 'leaf';
    case ElementType.trunk:
      return 'trunk';
  }
}

class TreeElement {
  String id;
  ElementType type;
  double x; // مركز العنصر بإحداثيات الكانفاس
  double y;
  double width;
  double height;
  double rotation; // راديان
  double scale;
  String text;
  bool locked;
  String? parentId;
  Color color;

  TreeElement({
    required this.id,
    required this.type,
    required this.x,
    required this.y,
    this.width = 140,
    this.height = 160,
    this.rotation = 0,
    this.scale = 1.0,
    this.text = '',
    this.locked = false,
    this.parentId,
    Color? color,
  }) : color = color ?? _defaultColorFor(type);

  static Color _defaultColorFor(ElementType type) {
    switch (type) {
      case ElementType.trunk:
        return const Color(0xFF6B4226);
      case ElementType.branch:
        return const Color(0xFF8A5A33);
      case ElementType.leaf:
        return const Color(0xFF4C8C4A);
    }
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': _typeToString(type),
        'x': x,
        'y': y,
        'width': width,
        'height': height,
        'rotation': rotation,
        'scale': scale,
        'text': text,
        'locked': locked,
        'parentId': parentId,
        'color': color.value,
      };

  factory TreeElement.fromJson(Map<String, dynamic> j) => TreeElement(
        id: j['id'] as String,
        type: _typeFromString(j['type'] as String),
        x: (j['x'] as num).toDouble(),
        y: (j['y'] as num).toDouble(),
        width: (j['width'] as num?)?.toDouble() ?? 140,
        height: (j['height'] as num?)?.toDouble() ?? 160,
        rotation: (j['rotation'] as num?)?.toDouble() ?? 0,
        scale: (j['scale'] as num?)?.toDouble() ?? 1.0,
        text: j['text'] as String? ?? '',
        locked: j['locked'] as bool? ?? false,
        parentId: j['parentId'] as String?,
        color: j['color'] != null ? Color(j['color'] as int) : null,
      );
}

// ----------------------------------------------------------------------------
// 2) الويدجت الرئيسي
// ----------------------------------------------------------------------------

class GenealogyCanvas extends StatefulWidget {
  const GenealogyCanvas({
    Key? key,
    this.width,
    this.height,
    required this.elementsJson,
    required this.onElementsChanged,
    this.triggerExport = false,
    this.onExportComplete,
  }) : super(key: key);

  final double? width;
  final double? height;

  /// JSON قادم من App State: { "elements": [ {...}, {...} ] }
  final String elementsJson;

  /// يُستدعى مرة واحدة بعد كل تغيير دائم (وليس أثناء السحب الفعلي)
  final Future<dynamic> Function(String updatedJson) onElementsChanged;

  /// يقلبه FlutterFlow من false->true لتشغيل التصدير (نبضة تشغيل)
  final bool triggerExport;

  /// يُستدعى مرة واحدة بعد انتهاء التصدير، يحمل مسار ملف الـ PDF النهائي
  final Future<dynamic> Function(String filePath)? onExportComplete;

  @override
  State<GenealogyCanvas> createState() => _GenealogyCanvasState();
}

class _GenealogyCanvasState extends State<GenealogyCanvas> {
  static const double canvasSize = 8000; // كانفاس كبير ثابت بدل "لا نهائي"

  final TransformationController _transformController =
      TransformationController();
  final Map<String, TreeElement> _elements = {};
  String? _selectedId;
  String? _expandedPanelId; // null = اللوحة مصغرة/مغلقة

  // -- متعلقة بالتصدير --
  final GlobalKey _canvasBoundaryKey = GlobalKey();
  bool _isExporting = false;
  double? _exportProgress; // 0.0 -> 1.0

  @override
  void initState() {
    super.initState();
    _loadFromJson(widget.elementsJson);
    // مركز العرض الابتدائي = منتصف الكانفاس
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _transformController.value = Matrix4.identity()
        ..translate(-canvasSize / 2 + 400, -canvasSize / 2 + 400);
    });
  }

  @override
  void didUpdateWidget(GenealogyCanvas oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.elementsJson != widget.elementsJson) {
      _loadFromJson(widget.elementsJson);
    }
    // اكتشاف "نبضة" التصدير عند تحوّل false -> true
    if (!oldWidget.triggerExport && widget.triggerExport && !_isExporting) {
      _exportTiled();
    }
  }

  void _loadFromJson(String jsonStr) {
    _elements.clear();
    if (jsonStr.trim().isEmpty) return;
    try {
      final decoded = jsonDecode(jsonStr) as Map<String, dynamic>;
      final list = (decoded['elements'] as List?) ?? [];
      for (final e in list) {
        final el = TreeElement.fromJson(e as Map<String, dynamic>);
        _elements[el.id] = el;
      }
    } catch (_) {
      // JSON غير صالح أو فارغ -> نبدأ بكانفاس خالٍ بدون رمي استثناء
    }
  }

  // ------------------------------------------------------------------------
  // الكتابة لمرة واحدة عند انتهاء أي تغيير دائم
  // ------------------------------------------------------------------------
  Future<void> _commit() async {
    final payload = jsonEncode({
      'elements': _elements.values.map((e) => e.toJson()).toList(),
    });
    await widget.onElementsChanged(payload);
  }

  // ------------------------------------------------------------------------
  // الإضافة المتسلسلة من نقطة المركز (Auto-Chain Add)
  // ------------------------------------------------------------------------
  void _addElement(ElementType type) {
    final newId = 'el_${DateTime.now().microsecondsSinceEpoch}';
    TreeElement? parent =
        _selectedId != null ? _elements[_selectedId] : null;

    double x, y;
    String? parentId;

    if (type == ElementType.trunk) {
      final center = _visibleCenterInCanvasSpace();
      x = center.dx;
      y = center.dy;
      parentId = null;
    } else if (type == ElementType.branch) {
      final trunk = parent?.type == ElementType.trunk
          ? parent
          : _elements.values
              .where((e) => e.type == ElementType.trunk)
              .cast<TreeElement?>()
              .firstWhere((e) => true, orElse: () => null);
      if (trunk == null) {
        return;
      }
      final siblingCount = _elements.values
          .where((e) => e.parentId == trunk.id && e.type == ElementType.branch)
          .length;
      final angle = -math.pi / 2 + (siblingCount * 0.45) - 0.9;
      x = trunk.x + math.cos(angle) * 160;
      y = trunk.y + math.sin(angle) * 160;
      parentId = trunk.id;
    } else {
      final branch = parent?.type == ElementType.branch
          ? parent
          : _elements.values
              .where((e) => e.type == ElementType.branch)
              .cast<TreeElement?>()
              .firstWhere((e) => true, orElse: () => null);
      if (branch == null) return;
      x = branch.x + 90;
      y = branch.y - 40;
      parentId = branch.id;
    }

    final newEl = TreeElement(id: newId, type: type, x: x, y: y, parentId: parentId);
    setState(() {
      _elements[newId] = newEl;
      _selectedId = newId;
      _expandedPanelId = newId;
    });
    _commit();
  }

  Offset _visibleCenterInCanvasSpace() {
    try {
      final inverse = Matrix4.inverted(_transformController.value);
      final screenCenter = Offset(
        (widget.width ?? 400) / 2,
        (widget.height ?? 600) / 2,
      );
      final transformed = MatrixUtils.transformPoint(inverse, screenCenter);
      return transformed;
    } catch (_) {
      return const Offset(canvasSize / 2, canvasSize / 2);
    }
  }

  void _cloneElement(String id) {
    final src = _elements[id];
    if (src == null) return;
    final newId = 'el_${DateTime.now().microsecondsSinceEpoch}';
    final clone = TreeElement(
      id: newId,
      type: src.type,
      x: src.x + 20,
      y: src.y + 20,
      width: src.width,
      height: src.height,
      rotation: src.rotation,
      scale: src.scale,
      text: src.text,
      parentId: src.parentId,
      color: src.color,
    );
    setState(() {
      _elements[newId] = clone;
      _selectedId = newId;
    });
    _commit();
  }

  void _deleteElement(String id, {bool cascade = false}) {
    setState(() {
      if (cascade) {
        final toDelete = <String>{id};
        bool changed = true;
        while (changed) {
          changed = false;
          for (final e in _elements.values) {
            if (e.parentId != null &&
                toDelete.contains(e.parentId) &&
                !toDelete.contains(e.id)) {
              toDelete.add(e.id);
              changed = true;
            }
          }
        }
        for (final tid in toDelete) {
          _elements.remove(tid);
        }
      } else {
        _elements.remove(id);
      }
      if (_selectedId == id) _selectedId = null;
      if (_expandedPanelId == id) _expandedPanelId = null;
    });
    _commit();
  }

  bool _hasChildren(String id) =>
      _elements.values.any((e) => e.parentId == id);

  // ------------------------------------------------------------------------
  // التصدير المقسّم (Tiled Export)
  // ------------------------------------------------------------------------
  Future<void> _exportTiled() async {
    if (_isExporting) return;
    setState(() {
      _isExporting = true;
      _exportProgress = 0.0;
    });

    final savedTransform = _transformController.value.clone();

    try {
      const double tileSize = 1024.0;
      final int tilesPerSide = (canvasSize / tileSize).ceil();
      final pdf = pw.Document();
      final int totalTiles = tilesPerSide * tilesPerSide;
      int doneTiles = 0;

      for (int row = 0; row < tilesPerSide; row++) {
        for (int col = 0; col < tilesPerSide; col++) {
          // حرّك الكانفاس برمجياً ليصبح هذا التجزيء فقط هو المرئي
          _transformController.value = Matrix4.identity()
            ..translate(-col * tileSize, -row * tileSize);

          // انتظر اكتمال إعادة الرسم فعلياً قبل التصوير
          setState(() {});
          await WidgetsBinding.instance.endOfFrame;
          await Future.delayed(const Duration(milliseconds: 16));

          final renderObject =
              _canvasBoundaryKey.currentContext?.findRenderObject();
          if (renderObject is! RenderRepaintBoundary) continue;
          final ui.Image image = await renderObject.toImage(pixelRatio: 1.5);
          final byteData =
              await image.toByteData(format: ui.ImageByteFormat.png);
          image.dispose();
          if (byteData == null) continue;
          final bytes = byteData.buffer.asUint8List();

          pdf.addPage(
            pw.Page(
              build: (ctx) => pw.Center(child: pw.Image(pw.MemoryImage(bytes))),
            ),
          );

          doneTiles++;
          setState(() => _exportProgress = doneTiles / totalTiles);
        }
      }

      final dir = await getApplicationDocumentsDirectory();
      final filePath =
          '${dir.path}/genealogy_export_${DateTime.now().millisecondsSinceEpoch}.pdf';
      final file = File(filePath);
      await file.writeAsBytes(await pdf.save());

      if (widget.onExportComplete != null) {
        await widget.onExportComplete!(filePath);
      }
    } finally {
      _transformController.value = savedTransform;
      setState(() {
        _isExporting = false;
        _exportProgress = null;
      });
    }
  }

  /// تصدير سريع للمنطقة المرئية فقط (PNG) — اختياري، يمكن ربطه بزر داخلي
  Future<String?> exportVisibleAreaOnly() async {
    final renderObject = _canvasBoundaryKey.currentContext?.findRenderObject();
    if (renderObject is! RenderRepaintBoundary) return null;
    final ui.Image image = await renderObject.toImage(pixelRatio: 2.0);
    final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
    image.dispose();
    if (byteData == null) return null;

    final dir = await getApplicationDocumentsDirectory();
    final filePath =
        '${dir.path}/genealogy_preview_${DateTime.now().millisecondsSinceEpoch}.png';
    final file = File(filePath);
    await file.writeAsBytes(byteData.buffer.asUint8List());
    return filePath;
  }

  // ------------------------------------------------------------------------
  // البناء
  // ------------------------------------------------------------------------
  @override
  Widget build(BuildContext context) {
    final w = widget.width ?? double.infinity;
    final h = widget.height ?? double.infinity;

    return SizedBox(
      width: w,
      height: h,
      child: Stack(
        children: [
          // ---- الكانفاس ----
          Positioned.fill(
            child: GestureDetector(
              onTap: () {
                setState(() {
                  _selectedId = null;
                  _expandedPanelId = null;
                });
              },
              child: InteractiveViewer(
                transformationController: _transformController,
                minScale: 0.1,
                maxScale: 4.0,
                boundaryMargin: const EdgeInsets.all(200),
                constrained: false,
                child: RepaintBoundary(
                  key: _canvasBoundaryKey,
                  child: SizedBox(
                    width: canvasSize,
                    height: canvasSize,
                    child: AnimatedBuilder(
                      animation: _transformController,
                      builder: (context, _) {
                        final visibleRect = _computeVisibleRect();
                        return Stack(
                          clipBehavior: Clip.none,
                          children: _buildConnectors(visibleRect) +
                              _buildElements(visibleRect),
                        );
                      },
                    ),
                  ),
                ),
              ),
            ),
          ),

          // ---- شريط الأدوات السفلي الثابت (منطقة لمس منفصلة تماماً) ----
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: _buildToolbar(),
          ),

          // ---- اللوحة العائمة لتعديل العنصر المحدد ----
          if (_selectedId != null && _elements.containsKey(_selectedId))
            _DraggablePanel(
              key: ValueKey('panel_${_selectedId}'),
              element: _elements[_selectedId]!,
              expanded: _expandedPanelId == _selectedId,
              onToggleExpand: () {
                setState(() {
                  _expandedPanelId =
                      _expandedPanelId == _selectedId ? null : _selectedId;
                });
              },
              onClose: () {
                setState(() {
                  _selectedId = null;
                  _expandedPanelId = null;
                });
              },
              onChanged: (updated) {
                setState(() => _elements[updated.id] = updated);
              },
              onChangeEnd: _commit,
              onClone: () => _cloneElement(_selectedId!),
              onDelete: () => _deleteElement(
                _selectedId!,
                cascade: _hasChildren(_selectedId!),
              ),
              hasChildren: _hasChildren(_selectedId!),
            ),

          // ---- طبقة حجب وعرض تقدّم التصدير ----
          if (_isExporting)
            Positioned.fill(
              child: AbsorbPointer(
                child: Container(
                  color: Colors.black.withOpacity(0.45),
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const CircularProgressIndicator(color: Colors.white),
                        const SizedBox(height: 12),
                        Text(
                          'جاري التصدير... ${(((_exportProgress ?? 0) * 100).toInt())}%',
                          style: const TextStyle(
                              color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  // Viewport culling: حساب المستطيل المرئي بإحداثيات الكانفاس
  Rect _computeVisibleRect() {
    try {
      final inverse = Matrix4.inverted(_transformController.value);
      final size = Size(widget.width ?? 400, widget.height ?? 600);
      final topLeft = MatrixUtils.transformPoint(inverse, Offset.zero);
      final bottomRight =
          MatrixUtils.transformPoint(inverse, Offset(size.width, size.height));
      const margin = 150.0; // هامش أمان
      return Rect.fromLTRB(
        topLeft.dx - margin,
        topLeft.dy - margin,
        bottomRight.dx + margin,
        bottomRight.dy + margin,
      );
    } catch (_) {
      return const Rect.fromLTWH(0, 0, canvasSize, canvasSize);
    }
  }

  List<Widget> _buildConnectors(Rect visible) {
    final widgets = <Widget>[];
    for (final el in _elements.values) {
      if (el.parentId == null) continue;
      final parent = _elements[el.parentId];
      if (parent == null) continue;
      final lineRect = Rect.fromPoints(
        Offset(parent.x, parent.y),
        Offset(el.x, el.y),
      );
      if (!lineRect.inflate(50).overlaps(visible)) continue;
      widgets.add(
        Positioned.fill(
          child: CustomPaint(
            painter: _ConnectorPainter(from: Offset(parent.x, parent.y), to: Offset(el.x, el.y)),
          ),
        ),
      );
    }
    return widgets;
  }

  List<Widget> _buildElements(Rect visible) {
    final sorted = _elements.values.toList()
      ..sort((a, b) => a.type.index.compareTo(b.type.index));

    final widgets = <Widget>[];
    for (final el in sorted) {
      final bounds = Rect.fromCenter(
        center: Offset(el.x, el.y),
        width: el.width * el.scale + 40,
        height: el.height * el.scale + 40,
      );
      if (!bounds.overlaps(visible)) continue; // Viewport Culling

      widgets.add(
        Positioned(
          left: el.x - (el.width * el.scale) / 2,
          top: el.y - (el.height * el.scale) / 2,
          width: el.width * el.scale,
          height: el.height * el.scale,
          child: RepaintBoundary(
            child: _ElementWidget(
              key: ValueKey(el.id),
              element: el,
              selected: _selectedId == el.id,
              onTap: () => setState(() => _selectedId = el.id),
              onLongPress: (globalPos) =>
                  _showContextMenu(context, globalPos, el),
              onDragUpdate: (delta) {
                if (el.locked) return;
                setState(() {
                  el.x += delta.dx;
                  el.y += delta.dy;
                });
              },
              onDragEnd: () => _commit(),
            ),
          ),
        ),
      );
    }
    return widgets;
  }

  void _showContextMenu(BuildContext context, Offset globalPos, TreeElement el) {
    final canAddChild =
        el.type == ElementType.trunk || el.type == ElementType.branch;
    showMenu<String>(
      context: context,
      position: RelativeRect.fromLTRB(
          globalPos.dx, globalPos.dy, globalPos.dx, globalPos.dy),
      items: [
        if (canAddChild)
          PopupMenuItem(
            value: 'add_child',
            child: Text(el.type == ElementType.trunk ? 'إضافة غصن' : 'إضافة ورقة'),
          ),
        const PopupMenuItem(value: 'edit', child: Text('تعديل')),
        const PopupMenuItem(value: 'clone', child: Text('نسخ')),
        PopupMenuItem(
            value: 'lock', child: Text(el.locked ? 'فتح القفل' : 'قفل')),
        const PopupMenuItem(value: 'delete', child: Text('حذف')),
      ],
    ).then((value) {
      if (value == null) return;
      setState(() => _selectedId = el.id);
      switch (value) {
        case 'add_child':
          _addElement(
              el.type == ElementType.trunk ? ElementType.branch : ElementType.leaf);
          break;
        case 'edit':
          setState(() => _expandedPanelId = el.id);
          break;
        case 'clone':
          _cloneElement(el.id);
          break;
        case 'lock':
          setState(() => el.locked = !el.locked);
          _commit();
          break;
        case 'delete':
          if (_hasChildren(el.id)) {
            _confirmCascadeDelete(el.id);
          } else {
            _deleteElement(el.id);
          }
          break;
      }
    });
  }

  void _confirmCascadeDelete(String id) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تأكيد الحذف'),
        content: const Text('هذا العنصر له عناصر مرتبطة به. سيتم حذف الفرع بالكامل. هل تريد الاستمرار؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              _deleteElement(id, cascade: true);
            },
            child: const Text('حذف', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  Widget _buildToolbar() {
    return Container(
      height: 64,
      color: Colors.white.withOpacity(0.97),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _toolButton(Icons.park, 'جذع', () => _addElement(ElementType.trunk)),
          _toolButton(Icons.account_tree, 'غصن', () => _addElement(ElementType.branch)),
          _toolButton(Icons.eco, 'ورقة', () => _addElement(ElementType.leaf)),
          const SizedBox(width: 24),
          // عجلة الزوم — منطقة لمس منفصلة تماماً (Hit-Test Isolation)
          _ZoomControls(controller: _transformController),
        ],
      ),
    );
  }

  Widget _toolButton(IconData icon, String label, VoidCallback onTap) {
    return Listener(
      onPointerDown: (_) {},
      child: TextButton.icon(
        onPressed: onTap,
        icon: Icon(icon, size: 20),
        label: Text(label),
      ),
    );
  }
}

// ----------------------------------------------------------------------------
// 3) عناصر الزوم في منطقة لمس منعزلة
// ----------------------------------------------------------------------------

class _ZoomControls extends StatelessWidget {
  const _ZoomControls({required this.controller});
  final TransformationController controller;

  void _zoom(double factor) {
    final current = controller.value.clone();
    final newMatrix = current..scale(factor);
    controller.value = newMatrix;
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      onPointerDown: (_) {},
      onPointerMove: (_) {},
      child: Row(
        children: [
          IconButton(icon: const Icon(Icons.zoom_out), onPressed: () => _zoom(0.8)),
          IconButton(icon: const Icon(Icons.zoom_in), onPressed: () => _zoom(1.25)),
        ],
      ),
    );
  }
}

// ----------------------------------------------------------------------------
// 4) ويدجت العنصر الواحد (سحب محلي + رسم الشكل)
// ----------------------------------------------------------------------------

class _ElementWidget extends StatefulWidget {
  const _ElementWidget({
    Key? key,
    required this.element,
    required this.selected,
    required this.onTap,
    required this.onLongPress,
    required this.onDragUpdate,
    required this.onDragEnd,
  }) : super(key: key);

  final TreeElement element;
  final bool selected;
  final VoidCallback onTap;
  final void Function(Offset globalPosition) onLongPress;
  final void Function(Offset delta) onDragUpdate;
  final VoidCallback onDragEnd;

  @override
  State<_ElementWidget> createState() => _ElementWidgetState();
}

class _ElementWidgetState extends State<_ElementWidget> {
  @override
  Widget build(BuildContext context) {
    final el = widget.element;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: widget.onTap,
      onLongPressStart: (d) => widget.onLongPress(d.globalPosition),
      onPanUpdate: (details) {
        if (!el.locked) widget.onDragUpdate(details.delta);
      },
      onPanEnd: (_) => widget.onDragEnd(),
      child: Transform.rotate(
        angle: el.rotation,
        child: CustomPaint(
          painter: _ShapePainter(type: el.type, color: el.color, selected: widget.selected),
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: FittedBox(
                child: Text(
                  el.text.isEmpty ? '...' : el.text,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ----------------------------------------------------------------------------
// 5) الرسم العضوي للأشكال الثلاثة
// ----------------------------------------------------------------------------

class _ShapePainter extends CustomPainter {
  _ShapePainter({required this.type, required this.color, required this.selected});
  final ElementType type;
  final Color color;
  final bool selected;

  @override
  void paint(Canvas canvas, Size size) {
    switch (type) {
      case ElementType.trunk:
        _paintTrunk(canvas, size);
        break;
      case ElementType.branch:
        _paintBranch(canvas, size);
        break;
      case ElementType.leaf:
        _paintLeaf(canvas, size);
        break;
    }
    if (selected) {
      final outline = Paint()
        ..color = Colors.blueAccent
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5;
      canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height).deflate(2), outline);
    }
  }

  void _paintTrunk(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final path = Path();
    path.moveTo(w * 0.38, 0);
    path.cubicTo(w * 0.30, h * 0.3, w * 0.32, h * 0.6, w * 0.18, h);
    path.lineTo(w * 0.82, h);
    path.cubicTo(w * 0.68, h * 0.6, w * 0.70, h * 0.3, w * 0.62, 0);
    path.close();

    final gradient = LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [_lighten(color, 0.15), color, _darken(color, 0.25)],
      stops: const [0.0, 0.5, 1.0],
    );
    final paint = Paint()..shader = gradient.createShader(Rect.fromLTWH(0, 0, w, h));

    canvas.drawShadow(path, Colors.black.withOpacity(0.35), 6, false);
    canvas.drawPath(path, paint);

    final innerShadow = Paint()
      ..shader = LinearGradient(
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
        colors: [Colors.black.withOpacity(0.25), Colors.transparent, Colors.white.withOpacity(0.08)],
      ).createShader(Rect.fromLTWH(0, 0, w, h));
    canvas.save();
    canvas.clipPath(path);
    canvas.drawRect(Rect.fromLTWH(0, 0, w, h), innerShadow);

    final barkPaint = Paint()
      ..color = Colors.black.withOpacity(0.12)
      ..strokeWidth = 1.2;
    for (int i = 1; i < 6; i++) {
      final dx = w * (0.2 + i * 0.1);
      canvas.drawLine(Offset(dx, h * 0.05), Offset(dx - 4, h * 0.95), barkPaint);
    }
    canvas.restore();
  }

  void _paintBranch(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final path = Path();
    path.moveTo(0, h * 0.85);
    path.quadraticBezierTo(w * 0.5, h * 0.55, w, h * 0.1);
    path.lineTo(w, h * 0.22);
    path.quadraticBezierTo(w * 0.5, h * 0.68, 0, h * 0.97);
    path.close();

    final gradient = LinearGradient(
      begin: Alignment.bottomLeft,
      end: Alignment.topRight,
      colors: [_darken(color, 0.2), color, _lighten(color, 0.1)],
    );
    final paint = Paint()..shader = gradient.createShader(Rect.fromLTWH(0, 0, w, h));
    canvas.drawShadow(path, Colors.black.withOpacity(0.25), 4, false);
    canvas.drawPath(path, paint);
  }

  void _paintLeaf(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final path = Path();
    path.moveTo(w / 2, 0);
    path.quadraticBezierTo(w, h * 0.32, w / 2, h);
    path.quadraticBezierTo(0, h * 0.32, w / 2, 0);
    path.close();

    final gradient = RadialGradient(
      center: const Alignment(-0.3, -0.4),
      radius: 1.0,
      colors: [_lighten(color, 0.2), color, _darken(color, 0.2)],
    );
    final paint = Paint()..shader = gradient.createShader(Rect.fromLTWH(0, 0, w, h));

    canvas.drawShadow(path, Colors.black.withOpacity(0.2), 5, false);
    canvas.drawPath(path, paint);

    final veinPaint = Paint()
      ..color = Colors.black.withOpacity(0.18)
      ..strokeWidth = 1.5;
    canvas.drawLine(Offset(w / 2, h * 0.1), Offset(w / 2, h * 0.9), veinPaint);
  }

  Color _lighten(Color c, double amount) {
    final hsl = HSLColor.fromColor(c);
    return hsl.withLightness((hsl.lightness + amount).clamp(0.0, 1.0)).toColor();
  }

  Color _darken(Color c, double amount) {
    final hsl = HSLColor.fromColor(c);
    return hsl.withLightness((hsl.lightness - amount).clamp(0.0, 1.0)).toColor();
  }

  @override
  bool shouldRepaint(covariant _ShapePainter oldDelegate) =>
      oldDelegate.color != color || oldDelegate.selected != selected || oldDelegate.type != type;
}

class _ConnectorPainter extends CustomPainter {
  _ConnectorPainter({required this.from, required this.to});
  final Offset from, to;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF8A5A33).withOpacity(0.6)
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke;
    final path = Path()
      ..moveTo(from.dx, from.dy)
      ..quadraticBezierTo((from.dx + to.dx) / 2, (from.dy + to.dy) / 2 - 30, to.dx, to.dy);
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _ConnectorPainter oldDelegate) =>
      oldDelegate.from != from || oldDelegate.to != to;
}

// ----------------------------------------------------------------------------
// 6) اللوحة العائمة القابلة للسحب
// ----------------------------------------------------------------------------

class _DraggablePanel extends StatefulWidget {
  const _DraggablePanel({
    Key? key,
    required this.element,
    required this.expanded,
    required this.onToggleExpand,
    required this.onClose,
    required this.onChanged,
    required this.onChangeEnd,
    required this.onClone,
    required this.onDelete,
    required this.hasChildren,
  }) : super(key: key);

  final TreeElement element;
  final bool expanded;
  final VoidCallback onToggleExpand;
  final VoidCallback onClose;
  final void Function(TreeElement updated) onChanged;
  final Future<void> Function() onChangeEnd;
  final VoidCallback onClone;
  final VoidCallback onDelete;
  final bool hasChildren;

  @override
  State<_DraggablePanel> createState() => _DraggablePanelState();
}

class _DraggablePanelState extends State<_DraggablePanel> {
  Offset _position = const Offset(20, 80);
  late TextEditingController _textController;

  @override
  void initState() {
    super.initState();
    _textController = TextEditingController(text: widget.element.text);
  }

  @override
  void didUpdateWidget(covariant _DraggablePanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.element.id != widget.element.id) {
      _textController.text = widget.element.text;
    }
  }

  @override
  Widget build(BuildContext context) {
    final el = widget.element;
    return Positioned(
      left: _position.dx,
      top: _position.dy,
      child: Material(
        elevation: 8,
        borderRadius: BorderRadius.circular(16),
        color: Colors.white.withOpacity(0.93),
        child: Container(
          width: widget.expanded ? 260 : 160,
          padding: const EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisSize: MainAxisSize.min,
            children: [
              GestureDetector(
                onPanUpdate: (d) => setState(() => _position += d.delta),
                child: Row(
                  children: [
                    const Icon(Icons.drag_indicator, size: 18),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        el.text.isEmpty ? _typeToString(el.type) : el.text,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                    IconButton(
                      icon: Icon(widget.expanded ? Icons.unfold_less : Icons.unfold_more, size: 18),
                      onPressed: widget.onToggleExpand,
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, size: 18),
                      onPressed: widget.onClose,
                    ),
                  ],
                ),
              ),
              if (widget.expanded) ...[
                const Divider(height: 12),
                TextField(
                  controller: _textController,
                  decoration: const InputDecoration(labelText: 'الاسم / النص'),
                  onChanged: (v) {
                    el.text = v;
                    widget.onChanged(el);
                  },
                  onEditingComplete: widget.onChangeEnd,
                  onSubmitted: (_) => widget.onChangeEnd(),
                ),
                const SizedBox(height: 8),
                const Text('الحجم'),
                Slider(
                  value: el.scale,
                  min: 0.4,
                  max: 2.5,
                  onChanged: el.locked
                      ? null
                      : (v) {
                          el.scale = v;
                          widget.onChanged(el);
                        },
                  onChangeEnd: (_) => widget.onChangeEnd(),
                ),
                const Text('الدوران'),
                Slider(
                  value: el.rotation,
                  min: -math.pi,
                  max: math.pi,
                  onChanged: el.locked
                      ? null
                      : (v) {
                          el.rotation = v;
                          widget.onChanged(el);
                        },
                  onChangeEnd: (_) => widget.onChangeEnd(),
                ),
                Row(
                  children: [
                    Expanded(
                      child: SwitchListTile(
                        contentPadding: EdgeInsets.zero,
                        dense: true,
                        title: const Text('قفل', style: TextStyle(fontSize: 13)),
                        value: el.locked,
                        onChanged: (v) {
                          el.locked = v;
                          widget.onChanged(el);
                          widget.onChangeEnd();
                        },
                      ),
                    ),
                  ],
                ),
                Row(
                  children: [
                    Expanded(
                      child: TextButton.icon(
                        onPressed: widget.onClone,
                        icon: const Icon(Icons.copy, size: 16),
                        label: const Text('نسخ'),
                      ),
                    ),
                    Expanded(
                      child: TextButton.icon(
                        onPressed: widget.onDelete,
                        icon: const Icon(Icons.delete, size: 16, color: Colors.red),
                        label: const Text('حذف', style: TextStyle(color: Colors.red)),
                      ),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
